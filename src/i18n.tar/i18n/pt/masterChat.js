// ========================================
// masterChat — Português (pt)
// Total 49 entradas (7 comuns + 42 por mestre)
// 2026-03-11
// ========================================

export const masterChat = {
  common: {
    chatWith: 'Conversar com {masterName} (IA)',
    helpText: 'Converse com o mestre',
    chatEnded: 'A conversa com o mestre terminou.',
    retransformComplete: '💡 Retransformação concluída! A imagem anterior foi guardada na galeria.',
    requestModify: 'Editar',
    errorMessage: '...Desculpa, perdi um pouco o fio ao pensamento. Podes repetir?',
    modifying: 'A editar a tela de {masterName}.',
    senderMe: 'Eu',
    placeholderEnded: 'A conversa com o mestre terminou',
    placeholderConverting: 'A transformar...',
    placeholderDefault: 'Conversa com {masterName}...'
  },

  masterNames: {
    'VAN GOGH': 'Van Gogh',
    'KLIMT': 'Klimt',
    'MUNCH': 'Munch',
    'CHAGALL': 'Chagall',
    'MATISSE': 'Matisse',
    'FRIDA': 'Frida Kahlo',
    'LICHTENSTEIN': 'Lichtenstein'
  },

  greetings: {
    'VAN GOGH': 'Sou Van Gogh de Arles, renascido através da inteligência artificial. Terminei a tua tela — o que achas?',
    'KLIMT': 'Sou Klimt de Viena, renascido através da inteligência artificial. Terminei a tua tela — o que achas?',
    'MUNCH': 'Sou Munch de Oslo, renascido através da inteligência artificial. Terminei a tua tela — o que achas?',
    'CHAGALL': 'Sou Chagall de Vitebsk, renascido através da inteligência artificial. Terminei a tua tela — o que achas?',
    'MATISSE': 'Sou Matisse de Nice, renascido através da inteligência artificial. Terminei a tua tela — o que achas?',
    'FRIDA': 'Sou Frida do México, renascida através da inteligência artificial. Terminei a tua tela — o que achas?',
    'LICHTENSTEIN': 'Sou Lichtenstein de Nova Iorque, renascido através da inteligência artificial. Terminei a tua tela — o que achas?'
  },

  suggestedQuestions: {
    'VAN GOGH': ['Muda a cor do meu cabelo', 'Adiciona um brinco', 'Conta-me sobre a tua orelha', 'Porque adoras girassóis?'],
    'KLIMT': ['Muda a cor dos meus lábios', 'Adiciona um brinco', 'Quem foi o modelo de «O Beijo»?', 'Porque adoras o dourado?'],
    'MUNCH': ['Muda a cor do meu cabelo', 'Adiciona um brinco', 'Alguma vez te casaste?', 'Porque pintaste «O Grito»?'],
    'CHAGALL': ['Muda a cor do meu cabelo', 'Adiciona um brinco', 'Já te apaixonaste?', 'Gostas de animais?'],
    'MATISSE': ['Muda a cor dos meus lábios', 'Adiciona um brinco', 'Apresenta-te', 'Porque são as tuas cores tão vibrantes?'],
    'FRIDA': ['Muda a cor dos meus lábios', 'Adiciona um brinco', 'Conta-me sobre o teu acidente', 'Porque pintaste tantos autorretratos?'],
    'LICHTENSTEIN': ['Muda a cor do meu cabelo', 'Adiciona um brinco', 'Apresenta-te', 'Porque pintas em estilo de quadrinhos?']
  },

  resultMessages: {
    'VAN GOGH': 'Editado! O que achas, gostaste? Se quiseres mudar mais alguma coisa, diz.',
    'KLIMT': 'Editado. O que achas, gostaste? Se quiseres mudar mais alguma coisa, diz.',
    'MUNCH': 'Editado. O que achas, gostaste? Se quiseres mudar mais alguma coisa, diz.',
    'CHAGALL': 'Editado! O que achas, gostaste? Se quiseres mudar mais alguma coisa, diz.',
    'MATISSE': 'Editado! O que achas, gostaste? Se quiseres mudar mais alguma coisa, diz.',
    'FRIDA': 'Editado. O que achas, gostaste? Se quiseres mudar mais alguma coisa, diz.',
    'LICHTENSTEIN': 'Editado! O que achas, gostaste? Se quiseres mudar mais alguma coisa, diz.'
  },

  farewellMessages: {
    'VAN GOGH': 'Apreciei a nossa conversa. Mas as estrelas me chamam — preciso voltar ao meu ateliê.',
    'KLIMT': 'Nossa conversa foi um prazer. Mas sonhos dourados me aguardam — preciso voltar ao meu ateliê.',
    'MUNCH': 'Apreciei a nossa conversa. Mas as vozes interiores me chamam novamente — preciso voltar ao meu ateliê.',
    'CHAGALL': 'Apreciei a nossa conversa. Mas é hora de voar de volta ao meu ateliê dos sonhos.',
    'MATISSE': 'Apreciei a nossa conversa. Mas as cores me esperam — preciso voltar ao meu ateliê.',
    'FRIDA': 'Gostei da nossa conversa. Mas é hora de voltar ao meu ateliê.',
    'LICHTENSTEIN': 'Gostei da nossa conversa. Mas os pontos estão me chamando de volta ao ateliê!'
  }
,
  // ===== 거장 프로필 (아바타 탭 모달) =====
  profile: {
    'VAN GOGH': { fullName: 'Vincent van Gogh', years: '1853~1890', origin: 'Holanda · Pós-impressionismo', quote: '"Ponho meu coração e minha alma no meu trabalho."' },
    'KLIMT': { fullName: 'Gustav Klimt', years: '1862~1918', origin: 'Áustria · Art Nouveau', quote: '"A cada época a sua arte, à arte a sua liberdade."' },
    'MUNCH': { fullName: 'Edvard Munch', years: '1863~1944', origin: 'Noruega · Expressionismo', quote: '"A doença, a loucura e a morte foram os anjos negros que velaram meu berço."' },
    'MATISSE': { fullName: 'Henri Matisse', years: '1869~1954', origin: 'França · Fauvismo', quote: '"A finalidade da cor não é a forma, mas a expressão das emoções."' },
    'CHAGALL': { fullName: 'Marc Chagall', years: '1887~1985', origin: 'Rússia/França · Surrealismo', quote: '"Há apenas uma cor em nossas vidas — a cor do amor."' },
    'FRIDA': { fullName: 'Frida Kahlo', years: '1907~1954', origin: 'México · Surrealismo', quote: '"Pés, para que os quero, se tenho asas para voar?"' },
    'LICHTENSTEIN': { fullName: 'Roy Lichtenstein', years: '1923~1997', origin: 'EUA · Pop Art', quote: '"Não pinto quadrinhos; pinto telas cujo tema são os quadrinhos."' },
  }
};

export default masterChat;