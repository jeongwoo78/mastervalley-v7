// ========================================
// UI Text — ภาษาไทย (th)
// 2026-03-11
// ========================================

export const ui = {
  // ===== CategorySelection =====
  category: {
    westernArt: 'ประวัติศาสตร์ศิลปะตะวันตก',
    westernArtDesc: 'เจาะลึก 2800 ปี',
    masterCollection: 'คอลเลกชันศิลปินเอก',
    masterCollectionDesc: 'พบกับ 7 ปรมาจารย์',
    eastAsianArt: 'จิตรกรรมตะวันออก',
    eastAsianArtDesc: 'ดื่มด่ำปรัชญาพันปีแห่งตะวันออก',
    tagline: 'การเดินทางข้ามกาลเวลาและพื้นที่',
    subTagline: 'พบกับปรมาจารย์แห่งตะวันออกและตะวันตก'
  },

  // ===== PhotoStyleScreen =====
  photoStyle: {
    tapToSelectPhoto: 'แตะเพื่อเลือกรูปภาพ',
    movementsName: 'ศิลปะตะวันตก',
    movementsTabName: 'ตะวันตก',
    mastersTabName: 'ศิลปินเอก',
    orientalTabName: 'ตะวันออก',
    mastersName: 'คอลเลกชันศิลปินเอก',
    orientalName: 'จิตรกรรมตะวันออก',
    fullTransform: 'แปลงทั้งหมด',
    movementsFullTransformLabel: 'ทั้ง 11 สไตล์ศิลปะ',
    mastersFullTransformLabel: 'ทั้ง 7 จิตรกรเอก',
    orientalFullTransformLabel: 'ศิลปะตะวันออกทั้งหมด',
    movementsFullTitle: 'เดินทาง 2800 ปีแห่งศิลปะ',
    movementsFullDesc: '11 ยุคสมัย',
    mastersFullTitle: 'สู่โลกของ 7 ศิลปินเอก',
    mastersFullDesc: 'พบกับ 7 ศิลปินเอก',
    orientalFullTitle: '1,000 ปีแห่งความงามตะวันออก',
    orientalFullDesc: 'จีน · ญี่ปุ่น · เกาหลี',
    perTransform: 'การแปลง',
    selectMovement: 'เลือกยุคสมัย',
    selectMaster: 'เลือกศิลปินเอก',
    mastersGalleryDesc: 'ผลงานจริงที่แปลงเป็น 7 สไตล์ศิลปินเอกโดย Master Valley',
    selectStyle: 'เลือกสไตล์',
    grecoRoman: 'กรีก-โรมัน',
    medieval: 'ยุคกลาง',
    renaissance: 'เรอเนสซองส์',
    baroque: 'บาโรก',
    rococo: 'โรโกโก',
    neoRomanReal: 'นีโอ · โรแมนติก · เรียลลิสม์',
    impressionism: 'อิมเพรสชันนิสม์',
    postImpressionism: 'โพสต์-อิมเพรส',
    fauvism: 'โฟวิสม์',
    expressionism: 'เอ็กซ์เพรสชันนิสม์',
    modernism: 'โมเดิร์นนิสม์',
    vanGogh: 'แวน โก๊ะ',
    klimt: 'คลิมต์',
    munch: 'มุงก์',
    matisse: 'มาติส',
    chagall: 'ชาการ์ล',
    frida: 'ฟรีดา',
    lichtenstein: 'ลิชเทนสไตน์',
    korean: 'เกาหลี',
    chinese: 'จีน',
    japanese: 'ญี่ปุ่น',
    koreanSub: 'มินฮวา · พุงซกโด',
    chineseSub: 'หมึกจีน · กงบีฮวา',
    japaneseSub: 'อุกิโยเอะ · รินปะ',
    artNotice: 'เนื่องจากลักษณะของผลงานชิ้นเอกต้นฉบับ บางสไตล์อาจมีภาพเปลือยเชิงศิลปะ',
    nudeWarningSingle: 'ภาพเปลือยเชิงศิลปะจากผลงานต้นฉบับอาจสะท้อนในผลลัพธ์',
    nudeWarningOneclick: 'ผลลัพธ์บางส่วนอาจสะท้อนภาพเปลือยเชิงศิลปะจากผลงานต้นฉบับ',
    movementsDesc1: '11 กระแสศิลปะ — ปรมาจารย์แห่งแต่ละยุคสมัยวาดภาพของคุณ',
    movementsDesc2: 'ด้วยการคลิกเดียว การเดินทางข้าม 2800 ปีของประวัติศาสตร์ศิลปะจะเริ่มต้น',
    mastersDesc1: 'ปรมาจารย์ 7 ท่านวาดคุณผ่านมุมมองเฉพาะตัวของพวกเขา',
    mastersDesc2: 'ด้วยการคลิกเดียว เจ็ดมุมมองและโลกเชื่อมต่อกันเป็นหนึ่ง',
    orientalDesc1: 'แปลงเป็นสไตล์ดั้งเดิมของจีน ญี่ปุ่น และเกาหลี',
    orientalDesc2: 'ด้วยการคลิกเดียว ดื่มด่ำกับสุนทรียศาสตร์และปรัชญาตะวันออกพันปี',
  },

  // ===== Processing =====
  processing: {
    analyzing: 'กำลังวิเคราะห์ภาพ...',
    inProgress: 'กำลังสร้างสรรค์...',
    masterInProgress: 'ปรมาจารย์ กำลังสร้างสรรค์...',
    checkingArtwork: 'กำลังตรวจสอบผลงาน...',
    done: 'เสร็จแล้ว!',
    movementsComplete: 'สไตล์ ผลงานปรมาจารย์เสร็จสมบูรณ์!',
    mastersComplete: 'ปรมาจารย์ ผลงานเสร็จสมบูรณ์!',
    nationsComplete: 'ประเทศ ผลงานปรมาจารย์เสร็จสมบูรณ์!',
    fullTransform: '✨ แปลงทั้งหมด',
    processingTitle: 'กำลังประมวลผล',
    tapToView: 'แตะเพื่อดูผลลัพธ์ที่เสร็จแล้ว',
    error: 'ข้อผิดพลาด',
    backBlocked: 'กำลังแปลงภาพ\nกรุณารอสักครู่',
    masterAtWork: 'ปรมาจารย์กำลังทำงาน...',
    allMastersJoining: 'ปรมาจารย์ทุกท่านเข้าร่วม...',
    doneLabel: 'ผลงานเสร็จ',
    masterDoneLabel: 'ผลงานปรมาจารย์เสร็จ',
    movementsLabel: 'ยุคสมัย',
    mastersLabel: 'ศิลปินเอก',
    nationsLabel: 'ชาติตะวันออก',
    movementsSub1: 'จากกรีกโบราณถึงโมเดิร์นนิสม์',
    movementsSub2: 'ข้ามผ่าน 2800 ปีของศิลปะตะวันตก',
    mastersSub1: 'ศิลปินผู้วาดโลกใหม่ด้วยภาษาของตน',
    mastersSub2: 'ตั้งคำถาม ทำลาย และสร้างใหม่',
    orientalSub1: 'จีน · ญี่ปุ่น · เกาหลี',
    orientalSub2: 'สามชาติ คล้ายกันแต่แตกต่าง',
    prev: '◀ ก่อนหน้า',
    next: 'ถัดไป ▶',
    downloading: 'กำลังดาวน์โหลด...'
  },

  // ===== Result =====
  result: {
    save: 'บันทึก',
    share: 'แชร์',
    gallery: 'แกลเลอรี',
    newPhoto: 'หน้าหลัก',
    modify: 'แก้ไข',
    retry: 'ลองใหม่',
    retryAll: 'ลองใหม่ทั้งหมด',
    retrying: 'กำลังลองใหม่...',
    conversionFailed: 'การแปลงล้มเหลว',
    aiRetrying: 'ปรมาจารย์กำลังลองใหม่...',
    refreshButton: 'รีเฟรช',
    refreshFailed: 'ไม่สามารถโหลดผลลัพธ์ได้',
    refreshing: 'กำลังโหลด...',
    refreshInProgress: 'ยังกำลังประมวลผล กรุณาลองอีกครั้งในอีกสักครู่',
    retryLimitExceeded: 'เกินขีดจำกัดการลองใหม่ (สูงสุด 3 ครั้ง)',
    retryServerError: 'เกิดข้อผิดพลาดในการลองใหม่ โปรดติดต่อฝ่ายสนับสนุน',
    retryUnauthorized: 'ไม่ได้รับอนุญาตให้ลองใหม่',
    noImageToSave: 'ไม่มีรูปภาพให้บันทึก',
    savedToGallery: 'บันทึกไปยังแกลเลอรีแล้ว!',
    saved: 'บันทึกแล้ว!',
    filesLocation: 'แอป Files → Documents → MasterValley',
    saveFailed: 'การบันทึกล้มเหลว',
    saveFailedRetry: 'การบันทึกล้มเหลว กรุณาลองใหม่',
    noImageToShare: 'ไม่มีรูปภาพให้แชร์',
    linkCopied: 'คัดลอกลิงก์ไปยังคลิปบอร์ดแล้ว!',
    retrySuccess: 'ลองใหม่สำเร็จ!',
    cancel: 'ยกเลิก',
    close: 'ปิด',
    retryFailed: 'การลองใหม่ล้มเหลว',
    saveToDevice: 'บันทึก',
    shareArt: 'แชร์',
    original: 'ต้นฉบับ',
    tapToSwipe: '← ปัดเพื่อดูผลลัพธ์ →',
    hide: 'ซ่อน',
    show: 'แสดง',
    shareTitle: 'Master Valley Art',
    shareText: '— Master Valley',
    loadingEducation: 'กำลังโหลดคำอธิบายผลงาน...',
    conversionFailedRetry: 'การแปลงล้มเหลว กรุณาแตะลองใหม่ด้านล่าง',
    retryAfterComplete: 'กรุณาลองใหม่หลังจากผลลัพธ์ทั้งหมดเสร็จสิ้น',
    convertedInStyle: 'ผลงานนี้ถูกแปลงในสไตล์ {style}'
  },

  // ===== Gallery =====
  gallery: {
    title: 'แกลเลอรี',
    deleteAll: 'ลบทั้งหมด',
    saved: 'บันทึกแล้ว',
    empty: 'ยังไม่มีรูปภาพที่บันทึก',
    emptySubtext: 'รูปภาพที่แปลงจะถูกบันทึกที่นี่',
    saveShare: 'บันทึก/แชร์',
    save: 'บันทึก',
    share: 'แชร์',
    close: 'ปิด',
    confirmDelete: 'ลบรูปภาพนี้?',
    confirmDeleteAll: 'ลบรูปภาพทั้งหมด?\nไม่สามารถยกเลิกได้',
    savedToGallery: 'บันทึกไปยังแกลเลอรีแล้ว!',
    savedToFiles: 'บันทึกแล้ว!\nDocuments → MasterValley',
    saveFailed: 'การบันทึกล้มเหลว',
    shareTitle: 'Master Valley Art',
    shareText: 'ผลงานชิ้นเอกใหม่จาก Master Valley',
    linkCopied: 'คัดลอกลิงก์ไปยังคลิปบอร์ดแล้ว!',
    loading: 'กำลังโหลดแกลเลอรี...',
    back: 'กลับ',
    home: 'หน้าหลัก',
    deviceNote: 'รูปภาพถูกบันทึกในอุปกรณ์ของคุณ',
    countUnit: '',
    delete: 'ลบ',
    saveToDevice: 'บันทึก',
    shareArt: 'แชร์',
    select: 'เลือก',
    selectAll: 'เลือกทั้งหมด',
    deselectAll: 'ยกเลิกทั้งหมด',
    deleteSelected: 'ลบที่เลือก',
    cancel: 'ยกเลิก',
    confirmDeleteSelected: 'ลบ {count} รูปภาพที่เลือก?',
    selectedCount: 'เลือก {count} รูปแล้ว',
    saving: 'กำลังบันทึก...',
    batchSaveComplete: 'บันทึก {count} รูปเสร็จแล้ว!',
    batchSavePartial: 'บันทึก {success} สำเร็จ, {fail} ล้มเหลว'
  },

  // ===== Menu =====
  menu: {
    title: 'ของฉัน',
    myGallery: 'แกลเลอรี',
    language: 'ภาษา',
    addFunds: 'เติมเครดิต',
    support: 'ฝ่ายสนับสนุน',
    logOut: 'ออกจากระบบ',
    contactUs: 'ติดต่อเรา',
    faq: 'คำถามที่พบบ่อย',
    deleteAccount: 'ลบบัญชี',
    about: 'เกี่ยวกับ'
  },



  // ===== AI Consent =====
  aiConsent: {
    message: 'รูปภาพของคุณจะถูกส่งไปยังผู้ให้บริการ AI บุคคลที่สามที่เชื่อถือได้เพื่อการแปลง และจะไม่ถูกเก็บรักษาหลังการประมวลผล ดูรายละเอียดเพิ่มเติมในนโยบายความเป็นส่วนตัวของเรา',
    confirm: 'ตกลง'
  },

  // ===== About =====
  about: {
    title: 'เกี่ยวกับ',
    version: 'เวอร์ชัน',
    termsOfService: 'ข้อกำหนดการใช้งาน',
    privacyPolicy: 'นโยบายความเป็นส่วนตัว',
    imageCredits: 'เครดิตรูปภาพ',
    lichtensteinCredit: 'Lichtenstein avatar: Eric Koch / Anefo (1967), CC BY-SA 3.0'
  },

  // ===== AddFunds =====
  addFunds: {
    title: 'เติมเครดิต',
    balance: 'ยอดคงเหลือ',
    mini: 'Mini',
    basic: 'Basic',
    standard: 'Standard',
    plus: 'Plus',
    pro: 'Pro',
    bonus: 'โบนัส',
    bestValue: 'คุ้มที่สุด',
    get: 'รับ',
    bonusLabel: 'โบนัส',
    tagStarter: 'เริ่มการเดินทางข้ามเวลา',
    tagStandard: 'สัมผัสโลกของปรมาจารย์',
    tagPlus: 'และค้นพบแรงบันดาลใจ',
    info1: 'ไม่มีการสมัครสมาชิก',
    info2: 'ยอดคงเหลือไม่มีวันหมดอายุ',
    purchaseComplete: 'ชำระเงินเสร็จสิ้น ยอดเงินของคุณจะอัปเดตในไม่ช้า'
  },

  // ===== Subscription Info =====
  subscriptionInfo: {
    line1: 'ไม่ต้องสมัครสมาชิก',
    line2: 'จ่ายเฉพาะเมื่อต้องการใช้งาน'
  },

  // ===== InsufficientBalance =====
  insufficientBalance: {
    title: 'เครดิตไม่เพียงพอ',
    requires: 'การแปลงนี้ต้องการ:',
    yourBalance: 'ยอดคงเหลือของคุณ:',
    recommended: 'แนะนำ',
    addFundsNow: 'เติมเครดิตเดี๋ยวนี้',
    maybeLater: 'ภายหลัง'
  },

  // ===== Language =====
  language: {
    title: 'ภาษา',
    current: 'ปัจจุบัน'
  },

    login: {
    tagline: 'ภาพหนึ่งใบ การเดินทางทางศิลปะ 2800 ปี',
    sub: 'มองโลกผ่านสายตาของปรมาจารย์',
    continueWithGoogle: 'ดำเนินการต่อด้วย Google',
    continueWithApple: 'ดำเนินการต่อด้วย Apple',
    email: 'อีเมล',
    password: 'รหัสผ่าน',
    logIn: 'เข้าสู่ระบบ',
    signUp: 'สมัครสมาชิก',
    pleaseWait: 'กรุณารอสักครู่...',
    loginCancelled: 'ยกเลิกการเข้าสู่ระบบ',
    networkError: 'เกิดข้อผิดพลาดเครือข่าย กรุณาลองใหม่',
    googleFailed: 'เข้าสู่ระบบด้วย Google ล้มเหลว',
    appleFailed: 'เข้าสู่ระบบด้วย Apple ล้มเหลว',
    emailInUse: 'อีเมลนี้ถูกใช้งานแล้ว',
    invalidEmail: 'รูปแบบอีเมลไม่ถูกต้อง',
    weakPassword: 'รหัสผ่านต้องมีอย่างน้อย 6 ตัวอักษร',
    wrongCredentials: 'อีเมลหรือรหัสผ่านไม่ถูกต้อง',
    loginFailed: 'เข้าสู่ระบบล้มเหลว กรุณาลองใหม่',
    forgotPassword: 'ลืมรหัสผ่าน?',
    resetEmailPrompt: 'กรอกอีเมลเพื่อรับลิงก์รีเซ็ต',
    resetEmailSent: 'ส่งอีเมลรีเซ็ตแล้ว กรุณาตรวจสอบกล่องจดหมายของคุณ',
    resetEmailRequired: 'กรุณากรอกอีเมลก่อน',
    resetEmailFailed: 'ส่งอีเมลรีเซ็ตไม่สำเร็จ',
    // Developer message
    devMsg1: 'ผมคือผู้พัฒนา Master Valley และเป็นผู้ใช้คนแรก',
    devMsg2: 'ศิลปินยุคเรอเนสซองส์ทำลายขนบคิดที่ยึดพระเจ้าเป็นศูนย์กลางมาพันปี และสถาปนาอุดมคติของมนุษย์ขึ้นใหม่',
    devMsg3: 'เมื่อการปฏิวัติผ่านไปและกล้องถือกำเนิด กล้องได้ถามว่า',
    devMsg4: '"ต่อไปนี้จะวาดอะไร?"',
    devMsg5: 'บางคนตอบด้วยแสง บางคนด้วยสี บางคนด้วยอารมณ์และมุมมองใหม่',
    devMsgHi1: 'ตอนนี้ AI กำลังถามคำถามเดียวกัน',
    devMsgHi2: '"เราจะทำอะไรต่อไป?"',
    devMsg6: '2800 ปีแห่งกระแสของตะวันตกและมุมมองของจิตรกรเอก ปรัชญาพันปีของตะวันออก',
    devMsg7: 'เบาะแสนั้นอยู่ใน Master Valley',
    devMsgSign: '— Jeongwoo, Master Valley',
    // Terms agreement (BLOCKER #46)
    termsAgreement: 'ฉันอายุ 18 ปีขึ้นไป และยอมรับ{terms}และ{privacy}',
    termsLink: 'ข้อกำหนดการใช้บริการ',
    privacyLink: 'นโยบายความเป็นส่วนตัว',
    termsRequired: 'กรุณายอมรับข้อกำหนดเพื่อดำเนินการต่อ',
  },

  // ===== Delete Account (BLOCKER #48) =====
  deleteAccount: {
    warningTitle: 'ลบบัญชี',
    warningIntro: 'การลบบัญชีเป็นการถาวร ข้อมูลต่อไปนี้ทั้งหมดจะถูกลบ:',
    warningItem1: 'ยอดคงเหลือ',
    warningItem2: 'ประวัติการแปลงและแกลเลอรีทั้งหมด',
    warningItem3: 'ข้อมูลบัญชี',
    warningIrreversible: 'ข้อมูลที่ถูกลบไม่สามารถกู้คืนได้',
    warningPurchaseNote: 'อย่างไรก็ตาม บันทึกการซื้อจะถูกทำให้ไม่ระบุตัวตนและเก็บไว้ตามกฎหมายที่บังคับใช้',
    warningContinueQuestion: 'คุณต้องการดำเนินการต่อหรือไม่?',
    warningContinueBtn: 'ดำเนินการต่อ',

    reauthTitle: 'การยืนยันตัวตน',
    reauthDesc: 'กรุณาเข้าสู่ระบบอีกครั้งเพื่อลบบัญชีของคุณ',
    reauthGoogleBtn: 'เข้าสู่ระบบด้วย Google อีกครั้ง',
    reauthAppleBtn: 'เข้าสู่ระบบด้วย Apple อีกครั้ง',
    reauthEmailLabel: 'รหัสผ่าน',
    reauthEmailBtn: 'ยืนยัน',

    deleting: 'กำลังลบบัญชีของคุณ...',
    deleteSuccess: 'บัญชีของคุณถูกลบแล้ว',
    deleteError: 'เกิดข้อผิดพลาดขณะลบ กรุณาลองอีกครั้ง',
    reauthError: 'การยืนยันตัวตนล้มเหลว',
    inProgressBlock: 'การแปลงกำลังดำเนินการอยู่ กรุณาลองอีกครั้งหลังจากเสร็จสิ้น',
  },

  // ===== Common =====
  common: {
    loading: 'กำลังโหลด...',
    error: 'ข้อผิดพลาด',
    cancel: 'ยกเลิก',
    confirm: 'ตกลง',
    back: 'กลับ',
    close: 'ปิด'
  }
};

export default ui;
