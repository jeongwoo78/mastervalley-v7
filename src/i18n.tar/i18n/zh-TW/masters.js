// ========================================
// 藝術大師 — 繁體中文 (zh-TW)
// i18n 結構 · 9行2段 (compact格式)
// v70 - 2026-03-04
// ========================================

export const mastersBasicInfo = {
  'vangogh': { loading: { name: '文森·梵谷 (1853–1890)', subtitle1: '後期印象主義 · 荷蘭', subtitle2: '旋轉的筆觸與熾烈的激情' },
    result: {
      name: '文森·梵谷 (1853–1890)',
      subtitle1: '星夜 · 向日葵 · 自畫像',
      subtitle2: '旋轉的筆觸與熾烈的激情',
      works: {
        'starrynight': { subtitle1: '星夜 (The Starry Night)', subtitle2: '柏樹與星辰在螺旋中' },
        'cafe': { subtitle1: '夜晚的咖啡館露臺 (Café Terrace at Night)', subtitle2: '星光下溫暖的黃色光芒' },
        'sunflowers': { subtitle1: '向日葵 (Sunflowers)', subtitle2: '沐浴陽光的花朵，燃燒著熱情' },
        'selfportrait': { subtitle1: '戴灰色氈帽的自畫像 (Self-Portrait with Grey Felt Hat)', subtitle2: '凝視靈魂之鏡' },
        'wheatfield': { subtitle1: '麥田與柏樹 (Wheat Field with Cypresses)', subtitle2: '金色麥田在風中搖曳' },
      }
    }, },
  'klimt': { loading: { name: '古斯塔夫·克林姆 (1862–1918)', subtitle1: '新藝術 · 奧地利', subtitle2: '金色的官能世界' },
    result: {
      name: '古斯塔夫·克林姆 (1862–1918)',
      subtitle1: '吻 · 乞蒂 · 生命之樹',
      subtitle2: '金色官能的世界',
      works: {
        'kiss': { subtitle1: '吻 (The Kiss)', subtitle2: '溶入金色的永恆之吻' },
        'treeoflife': { subtitle1: '生命之樹 (The Tree of Life)', subtitle2: '金色枝椏唱響生命之歌' },
        'judith': { subtitle1: '乞蒂一世 (Judith I)', subtitle2: '在神聖與官能之間，金色誘惑' },
      }
    }, },
  'munch': { loading: { name: '愛德華·孟克 (1863–1944)', subtitle1: '表現主義 · 挪威', subtitle2: '畫下內心的吶喊' },
    result: {
      name: '愛德華·孟克 (1863–1944)',
      subtitle1: '吶喊 · 聖母 · 生命之舞',
      subtitle2: '畫下內心的吶喊',
      works: {
        'scream': { subtitle1: '吶喊 (The Scream)', subtitle2: '血紅天空下靈魂的哭泣' },
        'madonna': { subtitle1: '聖母 (Madonna)', subtitle2: '生死之間的神秘人物' },
        'danceoflife': { subtitle1: '生命之舞 (The Dance of Life)', subtitle2: '愛與失落的華爾滋' },
      }
    }, },
  'matisse': { loading: { name: '亨利·馬諦斯 (1869–1954)', subtitle1: '野獸派 · 法國', subtitle2: '色彩的魔術師' },
    result: {
      name: '亨利·馬諦斯 (1869–1954)',
      subtitle1: '舞蹈 · 紅色房間 · 綠色條紋',
      subtitle2: '色彩的魔術師',
      works: {
        'greenstripe': { subtitle1: '綠色條紋 (The Green Stripe)', subtitle2: '宣告色彩革命的一道綠線' },
        'purplecoat': { subtitle1: '穿紫色外套的女人 (Woman in a Purple Coat)', subtitle2: '包裹在鮮豔色彩中的優雅' },
        'redroom': { subtitle1: '紅色房間 (The Red Room)', subtitle2: '被紅色主宰的裝飾盛宴' },
        'derain': { subtitle1: '安德烈·德朗肖像 (Portrait of André Derain)', subtitle2: '用野性色彩描繪的野獸派同儕' },
      }
    }, },
  'chagall': { loading: { name: '馬克·夏卡爾 (1887–1985)', subtitle1: '超現實主義 · 俄羅斯／法國', subtitle2: '愛與夢的詩人' },
    result: {
      name: '馬克·夏卡爾 (1887–1985)',
      subtitle1: '生日 · 我與村莊 · 新娘',
      subtitle2: '愛與夢的詩人',
      works: {
        'lovers': { subtitle1: '生日 (The Birthday)', subtitle2: '沉醉在愛中忘記重力的戀人' },
        'lamariee': { subtitle1: '新娘 (La Mariée)', subtitle2: '漂浮在夢與現實之間的新娘' },
        'village': { subtitle1: '我與村莊 (I and the Village)', subtitle2: '如夢般漂流的故鄉記憶' },
      }
    }, },
  'picasso': { loading: { name: '巴勃羅·畢卡索 (1881–1973)', subtitle1: '立體主義 · 西班牙', subtitle2: '解構視角的革命者' },
    result: {
      name: '巴勃羅·畢卡索 (1881–1973)',
      subtitle1: '亞維儂的少女 · 格爾尼卡 · 朵拉·瑪爾肖像',
      subtitle2: '解構視角的革命者',
      works: {
        'demoiselles': { subtitle1: '亞維儂的少女 (Les Demoiselles d\'Avignon)', subtitle2: '打破透視法的五位女性' },
        'guernica': { subtitle1: '格爾尼卡 (Guernica)', subtitle2: '在黑白中爆發的戰爭吶喊' },
        'doramaar': { subtitle1: '朵拉·瑪爾肖像 (Portrait of Dora Maar)', subtitle2: '正面與側面交匯的解構肖像' },
      }
    }, },
  'frida': { loading: { name: '芙烈達·卡蘿 (1907–1954)', subtitle1: '超現實主義 · 墨西哥', subtitle2: '直面痛苦的自畫像' },
    result: {
      name: '芙烈達·卡蘿 (1907–1954)',
      subtitle1: '我和我的鸚鵡們 · 破碎的柱子 · 與猴子的自畫像',
      subtitle2: '凝視痛苦的自畫像',
      works: {
        'parrots': { subtitle1: '我和我的鸚鵡們 (Me and My Parrots)', subtitle2: '與鸚鵡相伴的孤獨自畫像' },
        'brokencolumn': { subtitle1: '破碎的柱子 (The Broken Column)', subtitle2: '破碎身體中堅定不移的凝視' },
        'monkeys': { subtitle1: '與猴子的自畫像 (Self-Portrait with Monkeys)', subtitle2: '被猴子擁抱的痛苦肖像' },
      }
    }, },
  'lichtenstein': {
    loading: { name: '羅伊·乃乞登斯坦 (1923–1997)', subtitle1: '普普藝術 · 美國', subtitle2: '將漫畫變成藝術的人' },
    result: {
      name: '羅伊·乃乞登斯坦 (1923–1997)',
      subtitle1: 'Drowning Girl · Whaam! · In the Car',
      subtitle2: '將漫畫變成藝術的人',
      works: {
        'drowninggirl': { subtitle1: 'Drowning Girl (Drowning Girl)', subtitle2: '漫畫的戲劇搬上畫布' },
        'whaam': { subtitle1: 'Whaam! (Whaam!)', subtitle2: '漫畫爆炸即藝術' },
        'inthecar': { subtitle1: '在車內 (In the Car)', subtitle2: '漫畫中凝結的瞬間' },
        'mmaybe': { subtitle1: 'M-或許 (M-Maybe)', subtitle2: '猶豫一瞬間的普普戲劇' },
        'forgetit': { subtitle1: '算了！(Forget It!)', subtitle2: '一格漫畫裡的告別吶喊' },
        'ohhhalright': { subtitle1: '哦……好吧…… (Ohhh...Alright...)', subtitle2: '一句話盡道妥協與接受' },
        'stilllife': { subtitle1: '靜物 (Still Life with Crystal Bowl)', subtitle2: '本戴點重生的靜物世界' },
      }
    }
  },

  'vangogh-starry': { result: { name: '文森·梵谷 (1853–1890)', subtitle1: '星夜 (The Starry Night)', subtitle2: '柏樹與星辰在螺旋中' } },
  'vangogh-sunflower': { result: { name: '文森·梵谷 (1853–1890)', subtitle1: '向日葵 (Sunflowers)', subtitle2: '花瓶中的十五個太陽' } },
  'vangogh-selfportrait': { result: { name: '文森·梵谷 (1853–1890)', subtitle1: '自畫像 (Self-Portrait)', subtitle2: '世界上最誠實的凝視' } },
  'klimt-kiss': { result: { name: '古斯塔夫·克林姆 (1862–1918)', subtitle1: '吻 (The Kiss)', subtitle2: '金色包裹的愛' } },
  'klimt-judith': { result: { name: '古斯塔夫·克林姆 (1862–1918)', subtitle1: '乞蒂一世 (Judith I)', subtitle2: '誘惑與權力' } },
  'klimt-treeoflife': { result: { name: '古斯塔夫·克林姆 (1862–1918)', subtitle1: '生命之樹 (The Tree of Life)', subtitle2: '永恆的螺旋' } },
  'munch-scream': { result: { name: '愛德華·孟克 (1863–1944)', subtitle1: '吶喊 (The Scream)', subtitle2: '焦慮化為圖像' } },
  'munch-madonna': { result: { name: '愛德華·孟克 (1863–1944)', subtitle1: '聖母 (Madonna)', subtitle2: '聖潔與官能的交匯' } },
  'munch-puberty': { result: { name: '愛德華·孟克 (1863–1944)', subtitle1: '青春期 (Puberty)', subtitle2: '純真的不安' } },
  'matisse-dance': { result: { name: '亨利·馬諦斯 (1869–1954)', subtitle1: '舞蹈 (The Dance)', subtitle2: '身體的原始節奏' } },
  'matisse-redroom': { result: { name: '亨利·馬諦斯 (1869–1954)', subtitle1: '紅色房間 (The Red Room)', subtitle2: '被紅色淹沒的世界' } },
  'matisse-hat': { result: { name: '亨利·馬諦斯 (1869–1954)', subtitle1: '戴帽的女人 (Woman with a Hat)', subtitle2: '野獸派的第一槍' } },
  'chagall-overthecity': { result: { name: '馬克·夏卡爾 (1887–1985)', subtitle1: '在城市上空 (Over the Town)', subtitle2: '與戀人飛越城市上空' } },
  'chagall-iandthevillage': { result: { name: '馬克·夏卡爾 (1887–1985)', subtitle1: '我與村莊 (I and the Village)', subtitle2: '夢中的故鄉鄉愁' } },
  'chagall-bouquet': { result: { name: '馬克·夏卡爾 (1887–1985)', subtitle1: '花束與飛翔的戀人 (Bouquet with Flying Lovers)', subtitle2: '在愛中盛開的花' } },
  'picasso-demoiselles': { result: { name: '巴勃羅·畢卡索 (1881–1973)', subtitle1: '亞維儂的少女 (Les Demoiselles d\'Avignon)', subtitle2: '立體派的引爆' } },
  'picasso-guernica': { result: { name: '巴勃羅·畢卡索 (1881–1973)', subtitle1: '格爾尼卡 (Guernica)', subtitle2: '控訴戰爭的吶喊' } },
  'picasso-doramaar': { result: { name: '巴勃羅·畢卡索 (1881–1973)', subtitle1: '朵拉·瑪爾肖像 (Portrait of Dora Maar)', subtitle2: '正面與側面在一張臉上' } },
  'frida-brokencolumn': { result: { name: '芙烈達·卡蘿 (1907–1954)', subtitle1: '斷裂的圓柱 (The Broken Column)', subtitle2: '身體裂開，靈魂不屈' } },
  'frida-thornnecklace': { result: { name: '芙烈達·卡蘿 (1907–1954)', subtitle1: '帶荊棘項鍊與蜂鳥的自畫像 (Self-Portrait with Thorn Necklace and Hummingbird)', subtitle2: '痛苦是她的王冠' } },
  'frida-twofridaskahlo': { result: { name: '芙烈達·卡蘿 (1907–1954)', subtitle1: '兩個芙烈達 (The Two Fridas)', subtitle2: '兩顆心，一個芙烈達' } },
  'lichtenstein-drowninggirl': { result: { name: '羅伊·乃乞登斯坦 (1923–1997)', subtitle1: 'Drowning Girl (Drowning Girl)', subtitle2: '漫畫的戲劇搬上畫布' } },
  'lichtenstein-whaam': { result: { name: '羅伊·乃乞登斯坦 (1923–1997)', subtitle1: 'Whaam! (Whaam!)', subtitle2: '漫畫爆炸即藝術' } },
  'lichtenstein-inthecar': { result: { name: '羅伊·乃乞登斯坦 (1923–1997)', subtitle1: 'In the Car (In the Car)', subtitle2: '漫畫中凝結的瞬間' } }
};

export const mastersLoadingEducation = {
  'vangogh': { description: `厚塗技法與漩渦狀筆觸已被應用。
黃與藍的強烈對比直接表達靈魂的情感。

梵谷是後印象主義的決定性人物。
他在27歲開始繪畫，僅十年內便創作了900幅油畫，但生前只賣出一幅。
《星夜》、《向日葵》和《夜晚露天咖啡座》等傑作都誕生於貧困與精神痛苦之中。

他在37歲辭世——貧窮且默默無聞——但如今已成為史上最受愛戴的畫家。` },
  'klimt': { description: `真實金箔與受拜占庭馬賽克啟發的幾何圖案已被應用。
側面的矩形與頂部的圓形——裝飾細節如今環繞著您的身形。

克林姆是維也納世紀末新藝術運動的領軍畫家。
他創造了獨特技法，將油畫與金箔鑲嵌結合。

他最著名的作品〈吻〉描繪了一對被金色包裹的愛人，已成為浪漫主義的標誌性符號。` },
  'munch': { description: `漩渦曲線、扭曲形態與強烈色彩已被應用。
血紅色天空與波動線條表達深刻的焦慮與情感。

孟克是表現主義的先驅，他描繪的不是所見之物，而是所感之物。
他在5歲失去母親，14歲失去最愛的姐姐——這些創傷成為其作品永恆的源泉。

〈吶喊〉是存在主義恐懼的視覺表達，已成為藝術史上最具標誌性的圖像之一。` },
  'matisse': { description: `簡化的形態與大膽的原色已被應用。
重點不在解剖學的精確，而在透過色彩表達情感。

馬諦斯是野獸派的領袖——這個運動以狂野的色彩表達感受而非現實。
他在20歲罹患闌尾炎康復期間發現了繪畫，此後從未停止。

晚年無法再繪畫時，他以彩色剪紙創作——證明藝術沒有界限。` },
  'chagall': { description: `粉紅、鈷藍與珠寶般色彩的夢幻氛圍已被應用。
花束、漂浮的戀人與奇幻動物在夢境與現實之間飄浮。

夏卡爾出生於白俄羅斯的維捷布斯克，在那裡找到了生命所有的色彩。
他對妻子貝拉的愛成為其作品永恆的主題。

他在97年的生命中繪製愛與鄉愁的色彩——成為無與倫比的色彩詩人。` },
  'picasso': { description: `將主體解構為幾何平面並同時展現正面與側面的立體主義技法已被應用。
您的臉龐如今無處不在——同時從所有角度被觀看。

畢卡索是20世紀最具影響力的藝術家。
13歲時，他的繪畫水平已超越身為藝術老師的父親。

他與布拉克共同發展了立體主義——一場打破傳統透視並開啟抽象藝術大門的革命。` },
  'frida': { description: `傳統墨西哥民俗色彩、熱帶植物與動物共融已被應用。
在〈帶荊棘項鍊的自畫像〉中，痛苦化為藝術。

18歲時，芙烈達·卡蘿遭遇了一場可怕的巴士事故，脊椎嚴重受損。
在康復期間，她開始繪畫——將痛苦轉化為藝術。

她143幅畫作中，大多數是自畫像。「我畫自己，因為我時常孤獨，」她說。` },
  'lichtenstein': { description: `使用印刷漫畫本戴點、粗黑輪廓與原色的普普藝術技法已被應用。
您的臉龐如今宛如漫畫格——明亮、大膽且充滿戲劇性表情。

1961年，乃乞登斯坦繪製了一幅米老鼠漫畫，藝術界為之震動。
《生活》雜誌問道：「他是美國最差的藝術家嗎？」

如今他的作品以數千萬美元成交——證明流行文化就是藝術。` }
};

export const mastersResultEducation = {
  'vangogh-starry': { description: `星夜的宇宙螺旋已被應用。\n螺旋筆觸拖曳著星辰、月亮和夜空，創造出宇宙運動的幻象。\n\n深色柏樹如黑色火焰般聳立，每顆星辰都以自己的能量脈動。\n梵谷從聖雷米精神病院窗口畫下的傑作，後印象派最著名的作品。` },
  'vangogh-sunflower': { description: `向日葵的厚重顏料與鉻黃已被應用。\n黃色疊上黃色，顏料厚到獲得雕塑般的質感。\n\n從盛開到枯萎，生命力與衰敗同時被表現。\n梵谷為迎接好友高更而畫下的生命之爆發。` },
  'vangogh-selfportrait': { description: `〈自畫像〉的漩渦背景與厚重的厚塗筆觸已被應用。
冷調的綠與藍創造出心理的強度。

〈自畫像〉是梵谷凝視自己的鏡子——也是我們凝視他的窗口。
在十年的創作生涯中，他繪製了超過30幅自畫像，每幅都揭示靈魂的不同層面。

這幅以漩渦藍色為背景的自畫像，被視為他技巧能力與內心表達的巔峰之作。` },
  'klimt-kiss': { description: `〈吻〉的金箔背景與幾何裝飾圖案已被應用。
矩形與圓形交替排列，創造出包裹兩個身形的金色外衣。

〈吻〉是新藝術運動的傑作，如今已成為世界上最受愛戴的畫作之一。
真實黃金在畫布上閃耀——克林姆將傳統繪畫技法與奢華材料融為一體。

兩個相擁於懸崖邊的身影，已成為愛與脆弱的普世象徵。` },
  'klimt-judith': { description: `〈茱蒂絲〉的金箔裝飾與珠寶般的感官色彩已被應用。
透明絲絨與金色外衣創造出權力與慾望矛盾並存的表達。

〈茱蒂絲〉是舊約聖經中斬殺霍洛菲尼斯的女戰士——但克林姆描繪她不是英雄，而是狂喜的蛇蠍美人。

半閉的眼睛與微啟的嘴唇表情，在快感與勝利之間創造出克林姆標誌性的曖昧。` },
  'klimt-treeoflife': { description: `〈生命之樹〉的螺旋曲線與金色裝飾圖案已被應用。
三角形、眼睛與層疊的螺旋創造出生死交織的掛毯。

〈生命之樹〉是斯托克萊特壁飾的核心作品——克林姆為布魯塞爾一座宮殿創作的宏偉壁面裝飾。
螺旋分枝的樹象徵生命永恆的循環。

這是Gesamtkunstwerk的完美範例——融合繪畫、建築與工藝的整體藝術作品。` },
  'munch-scream': { description: `〈吶喊〉的波動曲線與扭曲形態已被應用。
血紅色天空與顫動的線條表達純粹的存在主義焦慮。

〈吶喊〉誕生於孟克的真實體驗——某個奧斯陸的黃昏，他感到大自然在向他「吶喊」。
三幅油畫版本與一幅粉彩版——每幅都捕捉了人類感受宇宙虛空的瞬間。

如今已成為全球最廣為人知的現代焦慮視覺符號。` },
  'munch-madonna': { description: `〈聖母〉的紅色光環與波動感官曲線已被應用。
在生與死的邊界，人物閉目而立。

〈聖母〉不是宗教意義的聖母——而是孟克對誕生、愛與死亡的禮讚，將三者融於一個形象之中。
紅色波浪環繞裸體人物，畫框中顯現胎兒與骷髏。

這是對生命永恆循環的冥想，只有孟克才能以如此勇氣表達。` },
  'munch-puberty': { description: `青春期的裸露脆弱與威脅陰影已被應用。\n少女裸身坐在床上，以恐懼和純真的目光注視觀者。\n\n身後的暗影如威脅般的存在隱現，具象化了成長的焦慮。\n最早捕捉從童年過渡到成年的無聲恐懼的作品之一。` },
  'matisse-dance': { description: `舞蹈的韻律人體與大膽原色已被應用。\n紅色身體在藍與綠的極簡空間中以原始能量舞蹈。\n\n五個人物形成純粹運動的圓圈，簡化至本質的姿態。\n馬諦斯宣告色彩即節奏、線條即情感的宣言。` },
  'matisse-redroom': { description: `〈紅色房間〉中違背透視的平面色彩構圖已被應用。
紅色牆壁與紅色桌子融為一體——阿拉伯式花紋圖案覆蓋整個空間。

〈紅色房間〉最初以藍色繪製，但馬諦斯在完成前將其重新塗成紅色。
甚至窗外的景色也呈現為平面裝飾——抹去室內與室外的界限。

這是馬諦斯勇氣的證明：色彩可以比現實更有力量。` },
  'matisse-hat': { description: `戴帽的女人非自然的面部色彩與大膽筆觸已被應用。\n鼻子上的綠色、額頭上的紫色、脖子上的橘色——驚嚇了觀眾的色彩。\n\n在1905年秋季沙龍上引發「野獸！」吶喊、為野獸派命名的作品。\n馬諦斯的宣言：色彩不是描述，而是表現。` },
  'chagall-overthecity': { description: `在城市上空的夢幻飄浮與粉彩色調已被應用。\n戀人自由飄浮在村莊屋頂上空，挑戰重力。\n\n維捷布斯克的屋頂在柔和色調中延展；在上方，夏卡爾與貝拉在色彩的狂喜中飛翔。\n最純粹地宣告愛可以讓我們飛翔的作品。` },
  'chagall-iandthevillage': { description: `我與村莊的夢幻多視角與記憶疊加已被應用。\n綠色人臉與白色山羊彼此對望；在山羊內部浮現擠奶的場景。\n\n倒置的屋頂、飄浮的人物、同時進行的場景編織記憶與夢境。\n通往夏卡爾童年的窗口，一切在無重力的夢中交融。` },
  'chagall-bouquet': { description: `花束與飛翔的戀人的明亮花朵與飛翔已被應用。\n巨大的花束向天空噴發，戀人在花瓣間飄浮。\n\n紅、藍、黃、綠如煙火般在暗色背景上爆發。\n夏卡爾以花束慶祝愛為永恆春天漂浮在空中的作品。` },
  'picasso-demoiselles': { description: `亞維儂的少女的激進解構與非洲面具已被應用。\n五具以不可能角度碎裂的身體，摧毀了文藝復興的透視法。\n\n右側兩張臉受非洲面具啟發，宣告立體派的誕生。\n揭開二十世紀藝術序幕的引爆，再現向解構投降。` },
  'picasso-guernica': { description: `格爾尼卡的紀念碑式構圖與撕裂的明暗已被應用。\n灰色調、黑與白——色彩的缺席強化了戰爭的恐怖。\n\n公牛、受傷的馬、燈泡和懷抱死嬰的母親，組成三公尺半高的視覺吶喊。\n藝術史上最有力的反戰宣言，在六週的憤怒中完成。` },
  'picasso-doramaar': { description: `〈朵拉·瑪爾肖像〉的正面與側面同時呈現已被應用。
強烈的原色填滿幾何平面。

朵拉·瑪爾是攝影師兼藝術家，二戰期間成為畢卡索的繆思與情人。
〈朵拉·瑪爾肖像〉從多個角度同時捕捉她的臉龐——是一個人心理複雜性的視覺表達。

畢卡索後來說：「朵拉，對我來說，永遠在哭泣。」這幅畫是她智慧與苦難的紀念碑。` },
  'frida-brokencolumn': { description: `斷裂的圓柱的解剖剖析與赤裸象徵已被應用。\n裂開的軀幹露出斷裂的愛奧尼亞圓柱；釘子刺入裸露的肌膚；淚水從乾涸的眼中流下。\n\n金屬束腰支撐著崩塌的身體，但她的目光依然挑戰。\n芙烈達最撕心裂肺的作品，痛苦成為身體地圖與抵抗宣言。` },
  'frida-thornnecklace': { description: `帶荊棘項鍊與蜂鳥的自畫像的正面圖標性與自然象徵已被應用。\n芙烈達直視觀者；荊棘如痛苦的項鍊環繞脖子，死去的蜂鳥懸掛如護身符。\n\n肩上的猴子，潛伏的黑貓——每個元素都是她苦難的密碼符號。\n綜合芙烈達美學的自畫像：墨西哥自然、痛苦與抵抗。` },
  'frida-twofridaskahlo': { description: `兩個芙烈達的象徵二元與情感寫實已被應用。\n兩個芙烈達並肩而坐，由連接她們外露心臟的動脈相連。\n\n穿白色洋裝的歐洲芙烈達心碎流血；墨西哥芙烈達握著乃戈的照片，心臟完好。\n在與乃戈·乃維拉離婚期間畫下的內心分裂傑作。` },
  'lichtenstein-drowninggirl': { description: `Drowning Girl的本戴點與漫畫戲劇已被應用。\n規則的點陣創造膚色陰影；粗黑輪廓定義情感的輪廓。\n\n女主角心想：「我不在乎……我寧願溺水也不想向乃拉德求救！」——漫畫情節劇被提升為藝術。\n證明一格漫畫可以承載藝術全部強度的作品。` },
  'lichtenstein-whaam': { description: `Whaam!的圖形爆炸與紀念碑尺度已被應用。\n兩幅並列：左邊戰機開火；右邊點與線的爆炸綻放。\n\n巨大的擬聲詞、速度線和碰撞星，將戰爭變成普普奇觀。\n將戰爭漫畫轉化為大型文化評論的普普藝術標誌性作品。` },
  'lichtenstein-inthecar': { description: `〈在車內〉的本戴點與粗黑輪廓已被應用。
只有純粹的原色填滿粗輪廓——如同放大的漫畫格。

〈在車內〉以乃乞登斯坦特有的漫畫風格捕捉車內的一對情侶。
平板的臉部表情與兩個人物之間的情感距離，創造出乃乞登斯坦標誌性的冷冽諷刺。

這幅畫提出一個問題：我們真的有所連結，還是只是連結的圖像？` },

  'vangogh_default': { description: `梵谷的表現主義風格——螺旋筆觸與強烈色彩已被應用。\n強勁有方向的筆觸創造出充滿情感能量的活躍質感。\n\n深藍與明黃的對比定義了這位用心作畫的畫家的調色盤。\n每一筆都揭示受折磨而充滿激情的靈魂的獨特風格。` },
  'klimt_default': { description: `克林姆的裝飾風格——金箔與幾何圖案已被應用。\n金色馬賽克與裝飾螺旋創造出感官奢華的世界。\n\n扁平人物被有機與幾何交織的圖案包裹。\n裝飾成為靈魂表現的維也納分離派美學。` },
  'munch_default': { description: `孟克的表現主義風格——不安的色彩與波動的形體已被應用。\n曲線與蒼白色調直接傳達心理焦慮。\n\n扭曲的景色跟隨內在情感的節奏，沒有什麼是穩定的。\n焦慮的視覺語言，將靈魂內容轉化為圖像的先驅。` },
  'matisse_default': { description: `馬諦斯的野獸派風格——純色與簡潔形體已被應用。\n大膽的原色不遵從現實排列，形體被還原至本質。\n\n線條成為舞蹈，色彩成為音樂——每個元素都以獨立的聲音歌唱。\n純粹喜悅的藝術，色彩從一切描述義務中獲得自由。` },
  'chagall_default': { description: `夏卡爾的夢幻風格——粉彩色調與飄浮人物已被應用。\n戀人、動物和屋頂在無重力的空間中飄浮，染上鄉愁。\n\n粉紅、紫色和藍色融合如夢中交錯的記憶。\n愛與記憶挑戰物理法則和時間的世界。` },
  'picasso_default': { description: `畢卡索的立體派風格——幾何形體與多重視角已被應用。\n面部與身體碎裂為稜角面，同時展現多個角度。\n\n大膽的線條與對比色構建被解構又重新組裝的現實。\n摧毀五百年傳統透視的視覺革命。` },
  'frida_default': { description: `芙烈達的象徵風格——墨西哥色彩與強烈正面凝視已被應用。\n紅、綠、黃的墨西哥傳統色彩框住極度個人的圖像學。\n\n每個元素——荊棘、動物、植物——都是痛苦、抵抗和愛的密碼符號。\n破碎的身體成為身分認同與鬥爭領域的告白藝術。` },
  'lichtenstein_default': { description: `乃乞登斯坦的普普風格——本戴點與粗輪廓已被應用。\n規則的點狀圖案與平塗原色將漫畫美學轉化為藝術。\n\n黑、紅、藍、黃在圖形構圖中質疑什麼是藝術、什麼是流行文化。\n消除美術館與大眾文化界線的普普藝術精髓。` },
  'vangogh-starrynight': {
    description: `〈星夜〉的漩渦厚塗筆觸已被應用。
鈷藍與鉻黃的強烈對比釋放出夜晚的能量。

〈星夜〉是梵谷對聖雷米療養院窗外景色的重新想像之作。
他並非描繪真實的夜空，而是將內心的動盪投射至群星之上。`
  },
  'vangogh-cafe': {
    description: `〈夜晚露天咖啡座〉的互補色夜景技法——不使用黑色——已被應用。
黃色煤氣燈與深藍夜空僅透過色彩對比表達黑暗。

〈夜晚露天咖啡座〉是梵谷在阿爾勒廣場星光下所畫的第一幅戶外夜景。
露台上的空椅與來往人影同時蘊含著夜晚的寧靜與溫暖。`
  },
  'vangogh-sunflowers': {
    description: `〈向日葵〉中單一鉻黃的細膩色調變化已被應用。
厚重的堆疊顏料如實捕捉花瓣的質感。

〈向日葵〉是梵谷為迎接高更到來、裝飾阿爾勒黃色小屋而創作的系列作品。
盛開的花朵、凋謝的花與種子共同揭示生命的循環。`
  },
  'vangogh-wheatfield': {
    description: `〈有絲柏的麥田〉的動態曲線筆觸與互補色對比已被應用。
被風吹動的麥穗與如火焰般的絲柏傳達自然的生命力。

〈有絲柏的麥田〉是梵谷在聖雷米療養院附近反覆描繪的風景。
麥田的金色地平線與垂直的絲柏連結天地。`
  },
  'matisse-greenstripe': {
    description: `〈綠色條紋〉中將臉部一分為二的大膽色面分割已被應用。
粉紅、黃與綠在皮膚上共存，完全無視自然色彩。

〈綠色條紋〉是馬諦斯為妻子阿梅莉所畫的肖像，在1905年沙龍引發「野獸！」的批評。
臉部中央一道綠色條紋僅靠色彩劃分光影。`
  },
  'matisse-purplecoat': {
    description: `〈穿紫色大衣的女人〉的強烈色面與裝飾性平面構圖已被應用。
人物與背景的界線消融，色彩本身創造出空間。

〈穿紫色大衣的女人〉是馬諦斯以簡化形態與純粹色彩傳達情感的作品。
紫色大衣的廣大色面主宰畫布，與背景圖案融為一體。`
  },
  'matisse-derain': {
    description: `〈安德烈·德蘭肖像〉的粗獷筆觸與非自然膚色已被應用。
綠色陰影與橙色皮膚，搭配大膽原色，以野獸派的狂野方式呈現人物。

〈安德烈·德蘭肖像〉是馬諦斯為同伴畫家安德烈·德蘭所畫的友誼肖像。
兩位畫家同時為彼此作畫，共同分享野獸派的實驗。`
  },
  'chagall-lovers': {
    description: `〈戀人〉的夢幻色彩與重疊意象已被應用。
粉紅、鈷藍與紫羅蘭融合，抹去夢境與現實的界線。

〈戀人〉是夏卡爾描繪對貝拉之愛的作品，貝拉是他一生的繆思與妻子。
如夢境般疊加在真實背景上的戀人表達了愛情的陶醉。`
  },
  'chagall-lamariee': {
    description: `〈新娘〉中紅色花束與藍色夜空的夢幻對比已被應用。
動物與人物如幻影般交融，展開節慶的奇幻景象。

〈新娘〉以夏卡爾故鄉維捷布斯克的屋頂與教堂尖塔作為記憶的風景。
手持紅色花束的新娘疊加在村莊場景上，同時蘊含鄉愁與喜悅。`
  },
  'chagall-village': {
    description: `〈我與村莊〉的多重透視與透明重疊意象已被應用。
人物、動物與村莊景色如夢般交融，無視比例與尺度。

〈我與村莊〉是夏卡爾在巴黎思念故鄉維捷布斯克時所作。
現實與記憶在同一畫布上融合，捕捉對家的無盡渴望。`
  },
  'munch-danceoflife': {
    description: `〈生命之舞〉中明暗色彩的象徵性對比已被應用。
以中央紅衣女子為軸，純真與絕望分置兩側。

〈生命之舞〉是孟克將愛與心碎的記憶壓縮在同一畫布上的自傳式作品。
明暗色彩在同一畫布上交替，捕捉愛的開始與終結。`
  },
  'frida-parrots': {
    description: `〈我與我的鸚鵡〉的強烈正面凝視與墨西哥民俗色彩已被應用。
鮮豔的紅、綠、藍與熱帶植物共同填滿畫布。

〈我與我的鸚鵡〉是芙烈達被四隻鸚鵡環繞的自畫像。
在墨西哥民間傳說中，鸚鵡是愛的使者，也是芙烈達孤獨中的忠實夥伴。`
  },
  'frida-monkeys': {
    description: `〈與猴子的自畫像〉的正面凝視與茂密熱帶背景已被應用。
在深綠葉叢中，她強烈的眼神與相連的眉毛揭示其身分認同。

〈與猴子的自畫像〉是芙烈達與寵物猴子共同入畫的自畫像。
在墨西哥神話中猴子象徵慾望，而對芙烈達而言，牠們是她無法擁有的孩子的替代。`
  },
  'lichtenstein-mmaybe': {
    description: `〈M-或許〉的本戴點與漫畫式對話框敘事已被應用。
原色在粗輪廓內平塗，重現印刷頁面的質感。

〈M-或許〉是乃乞登斯坦保存於個人收藏的作品，以三萬美元成交——是當時行情的五倍。
現作為德國科隆路德維希美術館普普藝術館藏的核心展品。`
  },
  'lichtenstein-forgetit': {
    description: `〈算了！〉的本戴點與強烈原色對比已被應用。
粗黑輪廓如漫畫格固定形態，戲劇性地壓縮情感。

〈算了！〉是乃乞登斯坦1962年首次個展後不久創作的早期傑作。
同年，《生活》雜誌以「他是美國最差的藝術家嗎？」為題報導他。`
  },
  'lichtenstein-ohhhalright': {
    description: `〈哦……好吧……〉的本戴點與平面色彩構圖已被應用。
紅、藍、黃在黑色輪廓內清晰分離，如同印刷頁面般銳利。

〈哦……好吧……〉是1964年取材自《祕密心事》第88期的作品。
2010年在佳士得以4260萬美元成交，顛覆了他曾稱之為「廢布」的價值。`
  },
  'lichtenstein-stilllife': {
    description: `〈靜物〉的本戴點與創造平面表現的粗輪廓已被應用。
原色色面以漫畫方式簡化物體，重現印刷質感。

〈靜物〉是乃乞登斯坦1970年代向畢卡索致敬、重新詮釋傳統類型的系列作品之一。
「我的靜物沒有情緒——就只是檸檬和葡萄柚，」他如此說道。`
  },

};

export default { mastersBasicInfo, mastersLoadingEducation, mastersResultEducation };
