// masterChat — tr (placeholder)
// TODO: Translate from en/ version

