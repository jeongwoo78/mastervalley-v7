// masterChat — id (placeholder)
// TODO: Translate from en/ version

